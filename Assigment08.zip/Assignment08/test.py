"""
test.py
Ben Clawson
12/11/2018
Changelog:
    12/11/2018, Ben Clawson, created script
"""

# Data
objFile = None  # File Handle
strUserInput = None  # A string which holds user input


# Processing
class readWrite:  # Created class
    def __init__(self, objFile, strUserInput):
        self.objFile = objFile
        self.strUserInput = strUserInput
        self.WriteProductUserInput = objFile.write(strUserInput + "\n")
        self.ReadAllFileData = objFile.read()


def WriteProductUserInput(self):  # WriteProductUserInput is now a method within the class 'writing'
    try:
        print("Type in a Product Id, Name, and Price you want to add to the file")
        print("(Enter 'Exit' to quit!)")
        while (True):
            strUserInput = input("Enter the Id, Name, and Price (ex. 1,ProductA,9.99): ")
            if (strUserInput.lower() == "exit"):
                break
            else:
                self.WriteProductUserInput(strUserInput)
    except Exception as e:
        print("Error: " + str(e))


def ReadAllFileData(self):
    try:
        print("Contents of File")
        objFile.seek(0)
        print(objFile.read())
    except Exception as e:
        print("Error: " + str(e))


# I/O


try:
    objFile = open("Products.txt", "r+")
    ReadAllFileData(objFile)
    WriteProductUserInput(objFile)
    ReadAllFileData(objFile)
except FileNotFoundError as e:
    print("Error: " + str(e) + "\n Please check the file name")
except Exception as e:
    print("Error: " + str(e))
finally:
    if objFile is not None: objFile.close()
input("press the enter key to exit ")