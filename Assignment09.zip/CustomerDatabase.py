"""
12/18/18
Ben Clawson
Assignment09
Changelog:
    12/18/18, BClawson,created script
"""

# Add code to your script that will perform that assignment’s task using modules and classes.
# The task this time is to create a new customer application that works like the Employees
# one we demonstrated in the Module 09 labs. You can use the code samples I included in the Module 09
# Python Programming Notes as a guide.
# --Constructor--

#-------------------------------------------------#
# Title: EmployeeApp
# Dev:   RRoot
# Date:  12/12/2020
# Desc: This application manages employee data
# ChangeLog: (Who, When, What)
    #12/18/18, BClawson, changed to CustomerApp
#
#-------------------------------------------------#
if __name__ == "__main__":
    import DataProcessor, Customer, Persons
else:
    raise Exception("This file was not created to be imported")

#-- Data --#
# declare variables and constants
objE = None #an Customer object
intId = 0 #an CustomerID
gIntLastId = 0 #Records the last CustomerID used in the client
strFirstName = "" #an Customer's first name
strLastName = "" #an Customer's last name
strInput = "" #temporary user input

#-- Processing --#
#perform tasks
def ProcessNewCustomerData(Id, FirstName, LastName):
    try:
        #Create Employee object
        objE = Customer.Customer()
        objE.Id = Id
        objE.FirstName = FirstName
        objE.LastName = LastName
        Customer.AddCustomer(Customer)
    except Exception as e:
        print(e)

def SaveDataToFile():
    try:
        objF = DataProcessor.File()
        objF.FileName = "CustomerData.txt"
        objF.TextData = Customer.CustomerList.ToString()
        print("Reached here")
        objF.SaveData()
    except Exception as e:
        print(e)

#-- Presentation (I/O) --#
#__main__

#get user input
strUserInput = ""
while(True):
  strUserInput = input("Would you like to add Customer data? (y/n)")
  if(strUserInput == "y"):
      #Get Customer Id from the User
      intId = int(input("Enter an Customer Id (Last id was " + str(gIntLastId) + "): "))
      gIntLastId = intId
      #Get Customer FirstName from the User
      strFirstName = str(input("Enter an Customer First Name: "))
      #Get Customer LastName from the User
      strLastName = str(input("Enter an Customer Last Name: ") )
      #Process input
      ProcessNewCustomerData(intId, strFirstName, strLastName)
  else:
      break

#send program output
print("The Current Data is: ")
print("------------------------")
print(Customer.CustomerList.ToString())

#get user input
strInput = input("Would you like to save this data to the dat file?(y/n)")
if(strInput == "y"):
    SaveDataToFile()
    #send program output
    print("data saved in file")
else:
    print("data was not saved")

print("This application has ended. Thank you!")

