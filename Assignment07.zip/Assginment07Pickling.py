#-------------------------------------------------#
# Title: Working with Pickling
# Dev:   BClawson
# Date:  December 04, 2018
# ChangeLog: (Who, When, What)
#   BClawson, 12/04/2018, created script
#-------------------------------------------------#

import pickle, shelve #I import the required modules housing the functions I want to use
#Data-----------------------------------
print("These are a list of complex data to be pickled and stored") #writing myself a message to show user
#what data are about to be pickled

customers = input("Enter customer name [last, first, middle initial]: ") #a customer ID from the user
quantity = int(input("Enter how many units the customer has ordered: ")) #a order detail from the user
orderType = input("What type did the customer order? sm/med/lg: ") #a random piece of data for this exercise
#Data-------------------------------

#Process----------------
objFile = open("pickleCustomerData.dat", "wb") #opens a binary file 'pickleCustomerData' and
#indicates file will be written to

pickle.dump(customers, objFile) #dumps the customer input into the file. Args = list, filename to write and store list
pickle.dump(quantity, objFile)#dumps the quantity input into the file. Args = list, filename to write and store list
pickle.dump(orderType, objFile)#dumps the orderType input into the file. Args = list, filename to write and store list

print("here's the unpickled list.") #writing myself a note to let user know the list will be unpickled
objFile = open("pickleCustomerData.dat", "rb") #opens the existing binary file 'pickleCustomerData and
#indicates the open function has 'read' privileges
customers = pickle.load(objFile)#unpickles the customer data. Args = file to pull data from and unpickle it
quantity = pickle.load(objFile)#unpickles the quantity data. Args = file to pull data from and unpickle it
orderType = pickle.load(objFile)#unpickles the orderType data. Args = file to pull data from and unpickle it

print("Shelved List")#writing myself a note to indicate the pickled data are about to be shelved
pickleShelf  = shelve.open("pickleShelf.dat")#shelving the pickled data above to a binary file 'pickleShelf.dat'.
#Args = file name

pickleShelf["customers"] = customers #created a shelved dictionary [ ] with the key of customers
pickleShelf["quantity"] = quantity #created a shelved dictionary [ ] with the key of quantity
pickleShelf["orderType"] = orderType #created a shelved dictionary [ ] with the key of orderType

pickleShelf.sync()#ensure the data are written
#Process-------------------


#Ouput---------------
print("Retrieve the pickled lists[dictionaries] from off the shelf") #pull down the pickled lists off the shelf and print them
print("Customers: ", pickleShelf["customers"]) #pull and print the customer pickle list
print("Quantity: ", pickleShelf["quantity"]) #pull and print the quantity pickle list
print("orderType: ", pickleShelf["orderType"]) #pull and print the orderType pickle list
pickleShelf.close() #close the shelfList binary file

input("press the enter key to close.")
#Output-------------------
